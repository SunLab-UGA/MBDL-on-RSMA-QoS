function H=Rayleigh_channel_def(N,M,num)% Rayleigh channel generation
    % H=randn(N,M)+randn(N,M)*1i;% rand channel matrix size is M*K，M antennas，K users
    if num == 1
        real_part = sqrt(0.5)*randn(N,M);
        imag_part = sqrt(0.5)*randn(N,M);
    else
        real_part = sqrt(0.5)*randn(N,M);
        imag_part = sqrt(0.5)*randn(N,M);
    end
    
    H = (real_part +1j*imag_part)/sqrt(M);
    % amp is 0,var is 1