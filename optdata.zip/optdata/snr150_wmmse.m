% EE-RSMA-FP 
clear;
close all;
clc;
%% basicParameters Initialization
warning('off')
WSR_record=[];

R1c_record=[];
R2c_record=[];
R3c_record=[]; 

f1_record=[];
f2_record=[];
f3_record=[];
v0_record=[];
v1_record=[];
v2_record=[];
v3_record=[];

r1_record=[];
r2_record=[];
r3_record=[];

rc1_record=[];
rc2_record=[];
rc3_record=[];


H1_record=[];
H2_record=[];
H3_record=[];

P0_record=[];
Pc_record=[];
P_max_record=[];

sigma_record=[];
count_break = [];
iteration_experiments_antennas = 0;
while length(WSR_record)<=1000
    iteration_experiments_antennas = iteration_experiments_antennas+1;
    flag=0;
    iteration_experiments_antennas
    EE_crb_record=[];
    f1=rand;
    f2=rand;
    f3=rand;
   
    sum_f=f1+f2+f3;
    f1=f1/sum_f;   
    f2=f2/sum_f;
    f3=f3/sum_f;
    iteration_experiments=1;
    M=12;
    % PT=10^((31-30)/10);
    PT=10^((33-30)/10);
    r1=abs(randn)/5;
    r2=abs(randn)/5;
    r3=abs(randn)/5;
    rc1=abs(randn)/100;
    rc2=abs(randn)/100;
    rc3=abs(randn)/100;
    % r1=abs(randn)/5+0.25;
    % r2=abs(randn)/5+0.25;
    % r3=abs(randn)/5+0.25;
    % % M = 8;
   count_break = [count_break, 1];
    N=1;
    K=3;
    % PT=10^((33-30)/10);
    Pc = 10^((30-30)/10);

    SNR_req = 15;% dB
    SNR_linear = 10^(SNR_req/10);
    pathloss = 1/sqrt(1000 / SNR_linear);
    if iteration_experiments==1
        H1=Rayleigh_channel_def(N,M,1)*pathloss;
        H2=Rayleigh_channel_def(N,M,2)*pathloss;
        H3=Rayleigh_channel_def(N,M,3)*pathloss;
    end
    % H1=H1/10*8;
    W=randn(M,K)+randn(M,K)*1i;% rand precoding matrix size is M*K，M antennas，K users
    W=(W-mean(W))./std(W);
    % v0=(H1'+H2'+H3')/18;
    % v1=H1'/18;
    % v2=H2'/18;
    % v3=H3'/18;
    v0=(H1+H2+H3)'/norm(H1'+H2'+H3');
    v1=H1'/norm(H1);
    v2=H2'/norm(H2);
    v3=H3'/norm(H3);
    power_control = 1/(norm(H1+H2+H3) *norm(H1) +norm(H1)*norm(H1)  + norm(H2)*norm(H2) + norm(H3)*norm(H3));
    v0=v0*sqrt((PT-Pc)*(norm(H1+H2+H3)*norm(H1+H2+H3)*power_control))/3;
    v1=v1*sqrt((PT-Pc)*(norm(H1)*norm(H1)*power_control))/3;
    v2=v2*sqrt((PT-Pc)*(norm(H2)*norm(H2)*power_control))/3;
    v3=v3*sqrt((PT-Pc)*(norm(H3)*norm(H3)*power_control))/3;
    V0=v0*v0';
    V1=v1*v1';
    V2=v2*v2';
    V3=v3*v3';
    %% Algorithm
    delta=1e-2;% precision for convergency 
    i=0;% initialize the counter
    EE=[];
    logtwo=log(2);
    AWGN_var=0.001;%-120dbm
    % -------------------------LOOP START------------------------
    while 1
        i=i+1;
        T_c1 = real(v0'*H1'*H1*v0 + v1'*H1'*H1*v1 + v2'*H1'*H1*v2 + v3'*H1'*H1*v3) + AWGN_var;
        T_c2 = real(v0'*H2'*H2*v0 + v1'*H2'*H2*v1 + v2'*H2'*H2*v2 + v3'*H2'*H2*v3) + AWGN_var;
        T_c3 = real(v0'*H3'*H3*v0 + v1'*H3'*H3*v1 + v2'*H3'*H3*v2 + v3'*H3'*H3*v3) + AWGN_var;

        T_1 = real(v1'*H1'*H1*v1 + v2'*H1'*H1*v2 + v3'*H1'*H1*v3) + AWGN_var;
        T_2 = real(v1'*H2'*H2*v1 + v2'*H2'*H2*v2 + v3'*H2'*H2*v3) + AWGN_var;
        T_3 = real(v1'*H3'*H3*v1 + v2'*H3'*H3*v2 + v3'*H3'*H3*v3) + AWGN_var;
        
        epsilon_c_1_wmmse = (T_c1-v0'*H1'*H1*v0)/T_c1;
        epsilon_c_2_wmmse = (T_c2-v0'*H2'*H2*v0)/T_c2;
        epsilon_c_3_wmmse = (T_c3-v0'*H3'*H3*v0)/T_c3;
        

        epsilon_1_wmmse = (T_1-v1'*H1'*H1*v1)/T_1;
        epsilon_2_wmmse = (T_2-v2'*H2'*H2*v2)/T_2;
        epsilon_3_wmmse = (T_3-v3'*H3'*H3*v3)/T_3;

        w_c1 = 1/real(epsilon_c_1_wmmse);
        w_c2 = 1/real(epsilon_c_2_wmmse);
        w_c3 = 1/real(epsilon_c_3_wmmse);
        
        w_1 = 1/real(epsilon_1_wmmse);
        w_2 = 1/real(epsilon_2_wmmse);
        w_3 = 1/real(epsilon_3_wmmse);

        g_1 = H1*v1/T_1;
        g_2 = H2*v2/T_2;
        g_3 = H3*v3/T_3;
        g_c1 = H1*v0/T_c1;
        g_c2 = H2*v0/T_c2;
        g_c3 = H3*v0/T_c3;

        % g_1 = real(sqrt(v1'*H1'*H1*v1)/T_1)
        % g_2 = real(sqrt(v2'*H2'*H2*v2)/T_2);
        % g_3 = real(sqrt(v3'*H3'*H3*v3)/T_3);
        % g_c1 = real(sqrt(v1'*H1'*H1*v1)/T_c1);
        % g_c2 = real(sqrt(v2'*H2'*H2*v2)/T_c2);
        % g_c3 = real(sqrt(v3'*H3'*H3*v3)/T_c3);
        cvx_begin sdp quiet
            variable V0(M,M) complex semidefinite 
            variable V1(M,M) complex semidefinite 
            variable V2(M,M) complex semidefinite 
            variable V3(M,M) complex semidefinite 
            % 公用速率
            variable X1
            variable X2
            variable X3
            % minimize(  f1*(X1+w_1*pinv(T_1)*(T_1-real(H1*V1*H1'))-log(w_1)*inv_pos(logtwo))+...
            %            f2*(X2+w_2*pinv(T_2)*(T_2-real(H2*V2*H2'))-log(w_2)*inv_pos(logtwo))+...
            %            f3*(X3+w_3*pinv(T_3)*(T_3-real(H3*V3*H3'))-log(w_3)*inv_pos(logtwo)))
            minimize(  f1*(X1+w_1*(1-2*real(sqrt(real(g_1'*H1*V1*H1'*g_1)))+g_1'*g_1*(AWGN_var+H1*(V1)*H1'+H1*(V2)*H1'+H1*(V3)*H1'))-log(w_1)*inv_pos(logtwo))+...
                       f2*(X2+w_2*(1-2*real(sqrt(real(g_2'*H2*V2*H2'*g_2)))+g_2'*g_2*(AWGN_var+H2*(V1)*H2'+H2*(V2)*H2'+H2*(V3)*H2'))-log(w_2)*inv_pos(logtwo))+...
                       f3*(X3+w_3*(1-2*real(sqrt(real(g_3'*H3*V3*H3'*g_3)))+g_3'*g_3*(AWGN_var+H3*(V1)*H3'+H3*(V2)*H3'+H3*(V3)*H3'))-log(w_3)*inv_pos(logtwo)))
            % minimize(  f1*(X1+w_1*(1-2*real(g_1*H1*v1)+g_1*g_1*T_1)-log(w_1)*inv_pos(logtwo))+...
            %            f2*(X2+w_2*(1-2*real(g_2*H2*v2)+g_2*g_2*T_2)-log(w_2)*inv_pos(logtwo))+...
            %            f3*(X3+w_3*(1-2*real(g_3*H3*v3)+g_3*g_3*T_3)-log(w_3)*inv_pos(logtwo)))
            subject to
                % X1 + X2 + X3 + 1>= w_c1*(1-2*real(g_c1*H1*v0)+g_c1*g_c1*T_c1)-log(w_c1)*inv_pos(logtwo); 
                % X1 + X2 + X3 + 1>= w_c2*(1-2*real(g_c2*H2*v0)+g_c2*g_c2*T_c2)-log(w_c2)*inv_pos(logtwo); 
                % X1 + X2 + X3 + 1>= w_c3*(1-2*real(g_c3*H3*v0)+g_c3*g_c3*T_c3)-log(w_c3)*inv_pos(logtwo); % power limitation
                % X1 + X2 + X3 + 1>= w_c1*(1-2*real(sqrt(real(g_c1*H1*V0*H1'*g_c1))))-log(w_c1)*inv_pos(logtwo);    
                X1 + X2 + X3 + 1>= w_c1*(1-2*real(sqrt(real(g_c1'*H1*V0*H1'*g_c1)))+real(g_c1'*(AWGN_var+H1*(V0)*H1'+H1*(V1)*H1'+H1*(V2)*H1'+H1*(V3)*H1')*g_c1))-log(w_c1)*inv_pos(logtwo);                % power limitation
                X1 + X2 + X3 + 1>= w_c2*(1-2*real(sqrt(real(g_c2'*H2*V0*H2'*g_c2)))+real(g_c2'*(AWGN_var+H2*(V0)*H2'+H2*(V1)*H2'+H2*(V2)*H2'+H2*(V3)*H2')*g_c2))-log(w_c2)*inv_pos(logtwo);
                X1 + X2 + X3 + 1>= w_c3*(1-2*real(sqrt(real(g_c3'*H3*V0*H3'*g_c3)))+real(g_c3'*(AWGN_var+H3*(V0)*H3'+H3*(V1)*H3'+H3*(V2)*H3'+H3*(V3)*H3')*g_c3))-log(w_c3)*inv_pos(logtwo);
                % norm(v0)+norm(v1)+norm(v2)+norm(v3)<=sqrt(PT-Pc);
                trace(V0)+trace(V1)+trace(V2)+trace(V3)+Pc<=PT;
                X1<=-rc1;
                X2<=-rc2;
                X3<=-rc3;
                % SINR constraints
                ((real(H1*V1*H1'))-r1*real(AWGN_var+H1*(V2)*H1'+H1*(V3)*H1'))>=0;
                ((real(H2*V2*H2'))-r2*real(AWGN_var+H2*(V1)*H2'+H2*(V3)*H2'))>=0;
                ((real(H3*V3*H3'))-r3*real(AWGN_var+H3*(V2)*H3'+H3*(V1)*H3'))>=0;
                
        cvx_end
        R1c = -X1;
        R2c = -X2;
        R3c = -X3;
        EE_item =  f1*(R1c+log(1+real(H1*V1*H1'/(AWGN_var+H1*(V2)*H1'+H1*(V3)*H1')))*inv_pos(logtwo))+...
                   f2*(R2c+log(1+real(H2*V2*H2'/(AWGN_var+H2*(V1)*H2'+H2*(V3)*H2')))*inv_pos(logtwo))+...
                   f3*(R3c+log(1+real(H3*V3*H3'/(AWGN_var+H3*(V2)*H3'+H3*(V1)*H3')))*inv_pos(logtwo))

        EE=[EE,EE_item];
        cvx_optval;
        % EE_item
        if isnan(EE_item)
            EE_item
        end
        if cvx_optval== -inf || cvx_optval== inf || isnan(cvx_optval) || i>20
            flag=1;
            break
        end
        [u0,val0]=eig(V0);
        [u1,val1]=eig(V1);
        [u2,val2]=eig(V2);
        [u3,val3]=eig(V3);
        v0_new=u0(:,M)*sqrt(val0(M,M));
        v1_new=u1(:,M)*sqrt(val1(M,M));
        v2_new=u2(:,M)*sqrt(val2(M,M));
        v3_new=u3(:,M)*sqrt(val3(M,M));
        v0_old = v0;
        v1_old = v1;
        v2_old = v2;
        v3_old = v3;
        alpha = 1;
        v0 = alpha*v0_new + (1-alpha)*v0_old;
        v1 = alpha*v1_new + (1-alpha)*v1_old;
        v2 = alpha*v2_new + (1-alpha)*v2_old;
        v3 = alpha*v3_new + (1-alpha)*v3_old;


        V0=v0*v0';
        V1=v1*v1';
        V2=v2*v2';
        V3=v3*v3';
        if i>1
            if abs(EE(i-1)-EE_item)<delta
                break
            end
        end
    end
    if flag==1
        continue
    else
        WSR_record=[WSR_record;EE_item];
        
        R1c_record=[R1c_record;R1c];
        R2c_record=[R2c_record;R2c];
        R3c_record=[R3c_record;R3c]; 
    
        f1_record=[f1_record;f1];
        f2_record=[f2_record;f2];
        f3_record=[f3_record;f3];
    
        v0_record=[v0_record;v0.'];
        v1_record=[v1_record;v1.'];
        v2_record=[v2_record;v2.'];
        v3_record=[v3_record;v3.'];
            
        r1_record=[r1_record;r1];
        r2_record=[r2_record;r2];
        r3_record=[r3_record;r3];
    
        rc1_record=[rc1_record;rc1];
        rc2_record=[rc2_record;rc2];
        rc3_record=[rc3_record;rc3];
    
        H1_record=[H1_record;conj(H1)];
        H2_record=[H2_record;conj(H2)];
        H3_record=[H3_record;conj(H3)];
        
        Pc_record=[Pc_record;Pc];
        P_max_record=[P_max_record;PT-Pc];
        
        sigma_record=[sigma_record;AWGN_var];
    end
end

% save org data
% save('WSR.mat','WSR_record');
% 
% save('R1c.mat','R1c_record');
% save('R2c.mat','R2c_record');
% save('R3c.mat','R3c_record');
% 
% save('f1.mat','f1_record');
% save('f2.mat','f2_record');
% save('f3.mat','f3_record');
% 
% save('r1.mat','r1_record');
% save('r2.mat','r2_record');
% save('r3.mat','r3_record');
% 
% save('rc1.mat','rc1_record');
% save('rc2.mat','rc2_record');
% save('rc3.mat','rc3_record');
% 
% save('v0.mat','v0_record');
% save('v1.mat','v1_record');
% save('v2.mat','v2_record');
% save('v3.mat','v3_record');
% 
% save('H1.mat','H1_record');
% save('H2.mat','H2_record');
% save('H3.mat','H3_record');
% 
% save('Pc.mat','Pc_record');
% 
% save('P_max.mat','P_max_record');
% 
% save('sigma.mat','sigma_record');

writematrix(WSR_record,'WSR.xlsx');
writematrix(f1_record,'f1.xlsx');
writematrix(f2_record,'f2.xlsx');
writematrix(f3_record,'f3.xlsx');

writematrix(R1c_record,'R1c.xlsx');
writematrix(R2c_record,'R2c.xlsx');
writematrix(R3c_record,'R3c.xlsx');

writematrix(rc1_record,'rc1.xlsx');
writematrix(rc2_record,'rc2.xlsx');
writematrix(rc3_record,'rc3.xlsx');

writematrix(r1_record,'r1.xlsx');
writematrix(r2_record,'r2.xlsx');
writematrix(r3_record,'r3.xlsx');

writematrix(real(v0_record),'v0_re.xlsx');
writematrix(real(v1_record),'v1_re.xlsx');
writematrix(real(v2_record),'v2_re.xlsx');
writematrix(real(v3_record),'v3_re.xlsx');

writematrix(imag(v0_record),'v0_im.xlsx');
writematrix(imag(v1_record),'v1_im.xlsx');
writematrix(imag(v2_record),'v2_im.xlsx');
writematrix(imag(v3_record),'v3_im.xlsx');

writematrix(real(H1_record),'H1_re.xlsx');
writematrix(real(H2_record),'H2_re.xlsx');
writematrix(real(H3_record),'H3_re.xlsx');

writematrix(imag(H1_record),'H1_im.xlsx');
writematrix(imag(H2_record),'H2_im.xlsx');
writematrix(imag(H3_record),'H3_im.xlsx');

writematrix(Pc_record,'Pc.xlsx');
writematrix(P_max_record,'P_max.xlsx');

writematrix(sigma_record,'sigma.xlsx');